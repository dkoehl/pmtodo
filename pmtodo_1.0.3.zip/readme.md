pixelmatic* New Media


#ToDo App
easy to use, full responsive (build with twitters Bootstrap). 

## TYPO3 CMS Extension
This app is an TYPO3 CMS Extension build with Extbase and Fluid, Frontend is using Twitter Bootstrap, jQuery, jQuery UI and jQuery Datepicker.

### Installation
Add the Extension to your TYPO3 CMS via Extension Manager (Download via Git or HTTP Download). Install the Extension as always. Add the static TypoScript (pmtodo) to your Page Template (Recommendation: Add the static TypoScript only to the Page where the Plugin is insert).

### Configuration
Insert the Plugin in a Page. Select your Data-Storage. 
####!Attention!
You should switch the Access-Settings of the Plugin, the Plugin should only be shown, when a valid Frontend-User is logged in. 

### Multiple User
The ToDo-App uses the common TYPO3 CMS Fe-User Management, every Frontend-User can use this App as his own Instance. You need an active FeUser-Session.


### Drag and Drop File-Upload
The files are default stored in uploads/tx_pmtodo/

### Resources and Frameworks
This Extension comes with all dependencies and is build for stand-alone.

### Screenshots 
You can find some screenshots in the wiki or at typo3 forge

### Related Links
https://forge.typo3.org/projects/extension-pmtodo/

https://dkoehl.github.io/pmtodo/

### Contact
Twitter: @pmnewmedia


